
let predictionResult = "";
let predictionHistory = [];
let total = 0, success = 0;

function checkPassword() {
    const pass = document.getElementById("password").value;
    if (pass === "jiten bhai") {
        document.getElementById("login-box").style.display = "none";
        document.getElementById("main-content").style.display = "block";
        startTimer();
    } else {
        alert("Wrong password!");
    }
}

function startTimer() {
    setInterval(() => {
        const now = new Date();
        const seconds = now.getSeconds();
        const display = seconds < 10 ? "0" + seconds : seconds;
        document.getElementById("timer").innerText = "Timer: " + display;

        if (seconds === 0) {
            generatePrediction(); // new prediction every minute
        }
    }, 1000);
}

function startPrediction() {
    document.getElementById("prediction-result").innerText = predictionResult;
}

function generatePrediction() {
    let bigSmall = Math.random() < 0.5 ? "BIG" : "SMALL";
    let num1 = Math.floor(Math.random() * 10);
    let num2;
    do {
        num2 = Math.floor(Math.random() * 10);
    } while (num2 === num1);

    predictionResult = `${bigSmall} | ${num1}, ${num2}`;

    let actualBigSmall = Math.random() < 0.5 ? "BIG" : "SMALL";
    let actualNum = Math.floor(Math.random() * 10);

    let status = (bigSmall === actualBigSmall && (num1 === actualNum || num2 === actualNum)) ? "WIN" : "FAIL";
    if (status === "WIN") success++;
    total++;

    predictionHistory.push({
        period: new Date().toLocaleTimeString(),
        prediction: predictionResult,
        actual: `${actualBigSmall} | ${actualNum}`,
        status: status
    });

    updateChart();
}

function updateChart() {
    const table = document.getElementById("chart-table");
    table.innerHTML = `
        <tr>
            <th>Period</th>
            <th>Prediction</th>
            <th>Actual</th>
            <th>Status</th>
        </tr>
    `;

    predictionHistory.slice(-10).reverse().forEach(row => {
        let color = row.status === "WIN" ? "lightgreen" : "tomato";
        table.innerHTML += `
            <tr style="color: ${color}">
                <td>${row.period}</td>
                <td>${row.prediction}</td>
                <td>${row.actual}</td>
                <td>${row.status}</td>
            </tr>
        `;
    });

    let acc = ((success / total) * 100).toFixed(1);
    document.getElementById("stats").innerText = `Total: ${total}, Win: ${success}, Accuracy: ${acc}%`;
}
